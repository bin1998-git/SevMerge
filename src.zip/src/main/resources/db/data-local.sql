-- ======================================================================================
-- 1. MEMBER_TB 초기 데이터 (최원종 파트: INSERT IGNORE 규격화 및 is_deleted 명시적 추가)
-- ======================================================================================
INSERT IGNORE INTO member_tb (id, email, password, name, phone, role, status, is_deleted, created_at)
VALUES (1, 'client01@sevmerge.com', '$2b$10$6om5ZhIXnA0qfyQwh7Y5xefzlXoacZzVMQEjBnpWskmVB/zWkhpJ2', '김의뢰', '010-1234-5678', 'CLIENT', 'ACTIVE', false, NOW());

INSERT IGNORE INTO member_tb (id, email, password, name, phone, role, status, is_deleted, created_at)
VALUES (2, 'expert01@sevmerge.com', '$2b$10$6om5ZhIXnA0qfyQwh7Y5xefzlXoacZzVMQEjBnpWskmVB/zWkhpJ2', '홍길동', '010-9876-5432', 'EXPERT', 'ACTIVE', false, NOW());

INSERT IGNORE INTO member_tb (id, email, password, name, phone, role, status, is_deleted, created_at)
VALUES (3, 'expert02@sevmerge.com', '$2b$10$6om5ZhIXnA0qfyQwh7Y5xefzlXoacZzVMQEjBnpWskmVB/zWkhpJ2', '김디자', '010-5555-4444', 'EXPERT', 'ACTIVE', false, NOW());

INSERT IGNORE INTO member_tb (id, email, password, name, phone, role, status, is_deleted, created_at)
VALUES (4, 'admin@sevmerge.com', '$2b$10$6om5ZhIXnA0qfyQwh7Y5xefzlXoacZzVMQEjBnpWskmVB/zWkhpJ2', '최관리', '010-0000-0000', 'ADMIN', 'ACTIVE', false, NOW());


-- ======================================================================================
-- 2. EXPERT_PROFILE 초기 데이터 (박효균 파트: member_id 기반 프로필 매핑 구조화)
-- ======================================================================================
-- id 1: 홍길동 프로필 (member_id = 2)
INSERT IGNORE INTO expert_profile (id, member_id, profile_image, intro, career, speciality, avg_rating, total_reviews, is_certified)
VALUES (1, 2, 'https://sevmerge.com/storage/profiles/expert_01.png',
        '안녕하세요! 대기업 출신 프리랜서 풀스택 개발자 홍길동입니다. 대규모 트래픽 처리 및 쇼핑몰, 커뮤니티 웹/앱 개발 전문입니다. 안정적이고 확장성 있는 아키텍처를 약속드립니다.',
        '- 前 카카오 백엔드 개발자 (3년)\n- 프리랜서 외주 개발 진행 (4년)\n- SevMerge 누적 프로젝트 20건 이상 완료',
        'Spring Boot, Java, AWS, React, Next.js', 4.95, 18, true);

-- id 2: 김디자 프로필 (member_id = 3)
INSERT IGNORE INTO expert_profile (id, member_id, profile_image, intro, career, speciality, avg_rating, total_reviews, is_certified)
VALUES (2, 3, 'https://sevmerge.com/storage/profiles/expert_02.png',
        '의뢰인님의 추상적인 아이디어를 트렌디하고 직관적인 화면으로 시각화해 드립니다. 와이어프레임 기획부터 피그마 고도화 프로토타입까지 책임지고 가이드해 드립니다.',
        '- 대형 IT 에이전시 수석 디자이너 (4년)\n- 스타트업 MVP 디자인 전담 프리랜서 활동 중',
        'Figma, UI/UX Design, Adobe XD, GUI, Branding', 4.80, 12, true);

-- id 3: 주니어 개발자 프로필 (member_id = 4 - 관리자 계정을 가상의 테스트용으로 매핑하거나 필요시 보정 가능)
INSERT IGNORE INTO expert_profile (id, member_id, profile_image, intro, career, speciality, avg_rating, total_reviews, is_certified)
VALUES (3, 4, 'https://sevmerge.com/storage/profiles/default.png',
        '성실함과 빠른 피드백으로 무장한 주니어 웹 개발자입니다. 스타트업 랜딩 페이지나 간단한 기업 소개 사이트를 합리적인 비용으로 빠르게 구축해 드립니다.',
        '- 컴퓨터공학과 졸업\n- 프론트엔드 외주 및 퍼블리싱 프로젝트 3회 진행',
        'HTML5, CSS3, JavaScript, Vue.js, Tailwind CSS', 0.00, 0, false);


-- ======================================================================================
-- 3. BOARD_TB 초기 데이터
-- ======================================================================================
-- 1번 샘플 (자유게시판): 작성자 홍길동 (member_id = 2)
INSERT IGNORE INTO board_tb (id, board_type, title, content, view_count, is_active, member_id, created_at)
VALUES (1, 'FREE', '프로젝트 낙찰률 200% 올리는 역제안서 작성 팁',
        'SevMerge에서 활동 중인 개발자입니다. 의뢰인의 기획서가 구체적이지 않을 때, 역으로 기능명세서를 가볍게 초안으로 작성해서 입찰 제안서에 첨부해 보세요. 클라이언트 신뢰도가 확 올라갑니다.',
        45, true, 2, NOW());

-- 2번 샘플 (자유게시판): 작성자 김의뢰 (member_id = 1)
INSERT IGNORE INTO board_tb (id, board_type, title, content, view_count, is_active, member_id, created_at)
VALUES (2, 'FREE', '스타트업 MVP 앱 외주 비용 보통 이 정도면 적당한가요?',
        '채팅이랑 결제 기능이 들어간 크로스플랫폼 앱인데, 예산을 500만 원에서 1,000만 원 사이로 잡고 등록하려 합니다. 전문가분들이 보시기에 입찰에 많이 참여하실 만한 합리적인 금액대인지 궁금합니다.',
        82, true, 1, NOW());

-- 3번 샘ায় (공지사항): 작성자 김디자 혹은 전문가 (member_id = 3)
INSERT IGNORE INTO board_tb (id, board_type, title, content, view_count, is_active, member_id, created_at)
VALUES (3, 'NOTICE', '[안내] 안심 대금 에스크로 수수료 정산 방식 변경 공지',
        '안녕하세요. SevMerge 팀입니다. 투명하고 공정한 외주 생태계를 위해 에스크로 안전 결제 시스템을 통한 전문가 정산 프로세스가 고도화되었습니다. 상세한 수수료 계산 방식(10%)은 결제 가이드를 참고해 주세요.',
        310, true, 3, NOW());


-- ======================================================================================
-- 4. PROJECT_TB 초기 데이터
-- ======================================================================================
-- 1번 샘플: 김의뢰 등록 (member_id = 1)
INSERT IGNORE INTO project_tb (id, member_id, title, category, description, budget_min, budget_max, deadline, bid_filter, project_status, view_count, is_deleted, created_at)
VALUES (1, 1, '스타트업 전용 중고 부품 거래 매칭 플랫폼 구축', 'WEB',
        '안녕하세요. 초기 스타트업 단계에서 프로토타입으로 사용할 중고 부품 거래 매칭 웹 및 하이브리드 앱 개발을 의뢰합니다. 상세 요구사항 정의서와 피그마 와이어프레임은 완비되어 있습니다. 결제 및 채팅 기능 구현이 필수적입니다.',
        5000000, 10000000, NOW(), 'ALL', 'OPEN', 0, false, NOW());

-- 2번 샘플: 최관리 혹은 타회원 등록 (member_id = 4)
INSERT IGNORE INTO project_tb (id, member_id, title, category, description, budget_min, budget_max, deadline, bid_filter, project_status, view_count, is_deleted, created_at)
VALUES (2, 4, '제조업 불량품 검출용 AI 컴퓨터 비전 모델 개발', 'APP',
        '공장 라인에서 촬영된 부품 이미지를 기반으로 불량 여부를 실시간 판별하는 딥러닝 모델 개발 건입니다. 데이터셋(약 1만 장)은 라벨링까지 완료되어 제공 가능합니다. 정확도(Accuracy) 95% 이상을 목표로 합니다. 관련 포트폴리오가 있는 팀만 지원 부탁드립니다.',
        8000000, 15000000, NOW(), 'ALL', 'OPEN', 0, false, NOW());

-- 3번 샘플: 김의뢰 등록 (member_id = 1)
INSERT IGNORE INTO project_tb (id, member_id, title, category, description, budget_min, budget_max, deadline, bid_filter, project_status, view_count, is_deleted, created_at)
VALUES (3, 1, '기업 리브랜딩을 위한 랜딩 페이지 및 UI/UX 디자인 고도화', 'APP',
        '기존 서비스의 웹 디자인 톤앤매너를 전면 수정하고 싶습니다. 반응형 웹 디자인을 지원해야 하며 신규 브랜드 로고(BI) 가이드라인을 제공해 드립니다.',
        2000000, 4000000, NOW(), 'ALL', 'OPEN', 0, false, NOW());


-- ======================================================================================
-- 5. BID_TB 초기 데이터
-- ======================================================================================
INSERT IGNORE INTO bid_tb (id, project_id, expert_id, cover_letter, approach, estimated_days, proposed_price, status, is_deleted, created_at) VALUES
(1, 1, 2, '웹 개발 5년 경력자입니다. 최선을 다하겠습니다.', 'React + Spring Boot로 개발하겠습니다.', 30, 2500000, 'PENDING', false, NOW()),
(2, 1, 3, '쇼핑몰 개발 다수 경험 있습니다.', 'Vue.js + Node.js로 개발하겠습니다.', 25, 2800000, 'PENDING', false, NOW()),
(3, 2, 3, '앱 개발 전문가입니다.', 'Flutter + Firebase로 개발하겠습니다.', 60, 8000000, 'PENDING', false, NOW()),
(4, 3, 2, 'UI/UX 디자인 전문입니다.', '피그마로 작업하겠습니다.', 14, 1500000, 'PENDING', false, NOW()),
(5, 3, 4, '데이터 분석 전문가입니다.', 'Python + Tableau로 개발하겠습니다.', 21, 3500000, 'PENDING', false, NOW());


-- ======================================================================================
-- 6. COMMENT_TB 초기 데이터
-- ======================================================================================
INSERT IGNORE INTO comment_tb (id, board_id, member_id, content, created_at)
VALUES (1, 1, 3, '오... 기능명세서 초안을 역으로 제안하는 방식은 생각 못 해봤는데 진짜 좋은 팁이네요. 다음 입찰 때 바로 써먹어 보겠습니다!', NOW());

INSERT IGNORE INTO comment_tb (id, board_id, member_id, content, created_at)
VALUES (2, 1, 4, '작성자님, 혹시 클라이언트가 요구사항을 아예 한 줄로만 적어둔 경우에도 이 방식이 통할까요? 기획 방향 잡기가 너무 어렵네요 ㅠㅠ', NOW());

INSERT IGNORE INTO comment_tb (id, board_id, member_id, content, created_at)
VALUES (3, 2, 2, '채팅에 결제까지 포함된 크로스플랫폼 앱이라면 요구사항 정의서 퀄리티에 따라 다르겠지만 700만~900만 원 선이 가장 매칭률이 높을 것 같습니다. 500만 원은 조금 타이트해 보이네요.', NOW());

INSERT IGNORE INTO comment_tb (id, board_id, member_id, content, created_at)
VALUES (4, 2, 1, '저도 딱 글쓴이님과 똑같은 스펙으로 SevMerge에 프로젝트 등록하려고 조율 중이었는데, 먼저 질문해 주셔서 좋은 정보 얻고 갑니다!', NOW());


-- ======================================================================================
-- 7. PAYMENT 초기 데이터 (박효균 파트: 토스 결제 도메인 이력 적재)
-- ======================================================================================
INSERT IGNORE INTO payment (id, project_id, client_id, expert_id, amount, platform_fee, net_amount, payment_key, method, status, paid_at)
VALUES (1, 1, 1, 2, 5000000, 500000, 4500000, 'imp_482019482103', 'card', 'PAID', NOW());

INSERT IGNORE INTO payment (id, project_id, client_id, expert_id, amount, platform_fee, net_amount, payment_key, method, status, paid_at)
VALUES (2, 2, 4, 2, 12000000, 1200000, 10800000, 'imp_910482019482', 'kakaopay', 'PAID', NOW());

INSERT IGNORE INTO payment (id, project_id, client_id, expert_id, amount, platform_fee, net_amount, payment_key, method, status, paid_at)
VALUES (3, 3, 1, 3, 1500000, 150000, 1350000, 'imp_vbank_009182', 'vbank', 'PAID', NOW());


-- ======================================================================================
-- 8. PORTFOLIO_TB 초기 데이터 (⚠️ 핵심 교정: expert_profile_id 관계에 맞춰 타겟 FK 대입 완료)
-- ======================================================================================
-- expert_id 고유 컬럼이 expert_profile 엔티티의 ID를 지칭하므로, 실제 프로필 등록 id(1=홍길동, 2=김디자, 3=주니어)에 정교하게 매칭
INSERT IGNORE INTO portfolio_tb (id, expert_id, title, description, image_url, project_url, created_at)
VALUES (1, 1, '대형 쇼핑몰 백엔드 시스템 구축',
        'Spring Boot 기반 대규모 트래픽 처리 쇼핑몰 백엔드 개발. 일 평균 10만 건 이상의 주문을 안정적으로 처리하는 아키텍처 설계 및 구현.',
        'https://sevmerge.com/storage/portfolios/portfolio_01.png',
        'https://github.com/honggildong/shopping-mall',
        NOW());

INSERT IGNORE INTO portfolio_tb (id, expert_id, title, description, image_url, project_url, created_at)
VALUES (2, 1, '실시간 채팅 기반 커뮤니티 플랫폼',
        'WebSocket을 활용한 실시간 채팅 및 알림 기능 구현. React + Spring Boot 풀스택 개발. AWS EC2 배포 및 RDS 운영.',
        'https://sevmerge.com/storage/portfolios/portfolio_02.png',
        'https://github.com/honggildong/community-platform',
        NOW());

INSERT IGNORE INTO portfolio_tb (id, expert_id, title, description, image_url, project_url, created_at)
VALUES (3, 2, '핀테크 스타트업 랜딩페이지 UI/UX 디자인',
        'Figma 기반 와이어프레임부터 고도화 프로토타입까지 전담. 브랜드 아이덴티티 정립 및 반응형 디자인 시스템 구축.',
        'https://sevmerge.com/storage/portfolios/portfolio_03.png',
        'https://www.figma.com/kimdesign/fintech-landing',
        NOW());

INSERT IGNORE INTO portfolio_tb (id, expert_id, title, description, image_url, project_url, created_at)
VALUES (4, 2, '헬스케어 모바일 앱 UI/UX 디자인',
        '운동 기록 및 식단 관리 앱 전체 화면 설계. 사용자 인터뷰 기반 UX 리서치 진행 후 직관적인 UI 구현. Adobe XD 프로토타입 납품.',
        'https://sevmerge.com/storage/portfolios/portfolio_04.png',
        'https://www.figma.com/kimdesign/healthcare-app',
        NOW());

INSERT IGNORE INTO portfolio_tb (id, expert_id, title, description, image_url, project_url, created_at)
VALUES (5, 3, '기업 소개 웹사이트 퍼블리싱',
        'HTML5, CSS3, JavaScript 기반 반응형 기업 소개 사이트 퍼블리싱. Vue.js 및 Tailwind CSS 활용하여 빠른 개발 완료.',
        'https://github.com/junior-dev/company-website',
        NOW());


-- ======================================================================================
-- 9. REVIEW_TB 초기 데이터 (⚠️ 핵심 교정: 홍길동 프로필 expert_profile_id = 1번에 정상 할당)
-- ======================================================================================
INSERT IGNORE INTO review_tb (id, expert_profile_id, member_id, count_star, content, created_at, review_type)
VALUES (1, 1, 1, 5, '정말 꼼꼼하고 빠르게 작업해 주셨어요. 요구사항을 잘 이해하고 결과물도 깔끔했습니다.', NOW(), 'CLIENT_TO_EXPERT');

INSERT IGNORE INTO review_tb (id, expert_profile_id, member_id, count_star, content, created_at, review_type)
VALUES (2, 1, 4, 4, '소통이 원활하고 일정도 잘 지켜주셨습니다. 다음에도 함께하고 싶어요.', NOW(), 'CLIENT_TO_EXPERT');

INSERT IGNORE INTO review_tb (id, expert_profile_id, member_id, count_star, content, created_at, review_type)
VALUES (3, 1, 1, 5, '기술적으로 매우 뛰어나신 분입니다. 복잡한 작업도 깔끔하게 처리해 주셨어요.', NOW(), 'CLIENT_TO_EXPERT');