package com.example.SevMerge.core.config;

import com.solapi.sdk.SolapiClient;
import com.solapi.sdk.message.service.DefaultMessageService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SolApiConfig {
    @Value("${solapi.api-key}")
    private String apiKey;

    @Value("${solapi.api-secret}")
    private String apiSecret;

    @Bean
    public DefaultMessageService defaultMessageService() {
        return SolapiClient.INSTANCE.createInstance(apiKey, apiSecret);
    }

}
