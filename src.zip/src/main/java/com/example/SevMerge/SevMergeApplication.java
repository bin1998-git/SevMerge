package com.example.SevMerge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
public class SevMergeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SevMergeApplication.class, args);
	}

}
